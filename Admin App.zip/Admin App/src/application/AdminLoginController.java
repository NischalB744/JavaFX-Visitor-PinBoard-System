package application;

import java.io.FileWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import com.sun.prism.paint.Color;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.SwipeEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Callback;

public class AdminLoginController<myBorderPane> implements Initializable
 {
	@FXML
    private MenuItem menuItemByDate;

    @FXML
    private MenuItem menuItemAnalyze;
    @FXML
    private MenuItem menuItemAdd;
    @FXML
    private MenuItem menuItemEdit;
    @FXML
    private MenuItem menuItemHome;
    @FXML
    private BorderPane myBorderPane;
    
    @FXML
    private MenuBar myMenuBar;
    
    @FXML
    private VBox vBoxForDisplay;
    
    @FXML
    private Button submitAnalysis;
    
    @FXML
    private Button btnTextClear;
    
    @FXML
    private Button btnTextClear1;
    
    @FXML
    private TextField txtFieldZip;
    @FXML
    private    /**TextField*/ComboBox<String> txtFieldState;
    @FXML
    private TextField txtFieldCity;
    @FXML
    private TextField txtFieldCountry;
    
    @FXML
    private Label addLabel;
    @FXML
    private TextField addZip;
    @FXML
    private TextField addCity;
    @FXML
    private TextField addCountry;
    @FXML
    private TextField addEmail;
    @FXML
    private ComboBox<String> addHotel;
    @FXML
    private ComboBox<String> addState;
    @FXML
    private ComboBox<String> addpurpose;
    @FXML
    private DatePicker addDate;
    @FXML
    private ComboBox<String> addNumofVisitor;
    @FXML
    private Button addButton;
    
    
    @FXML
    private Button editButton;
    
    @FXML
    private Button updateButton;
    
    @FXML
    private /**TextField*/ComboBox<String> purpose;
    @FXML
    private ComboBox<String> txtFieldHotelstay;
    @FXML
    private Label labelDisplay;
    
    @FXML
    private TextField labelStartDate;
    
    @FXML 
    private HBox hBoxForDisplay;
    
    @FXML
    private BarChart<String, Integer> bc;
   
    @FXML
    private  PieChart chart;

    @FXML
    private NumberAxis yAxis;

    @FXML
    private CategoryAxis xAxis;
    
    @FXML
    private Button submitButton;
    
    @FXML
    private Button enterButton;
    
    @FXML
    private Button importCSVButton;
    
    @FXML
    private DatePicker startDate;
    
    @FXML
    private DatePicker endDate;
    
    @FXML
    private ScrollPane scrollPaneForTable;
 
    DBConnection myDataBase = new DBConnection();
    
    //For HBox of Pie Chart, Bar, and Line
    @FXML
    private HBox hBoxForPieBarLineChart;
   
    
    //To initializing the variables for getting input
    private String inputZipCode;
    private String inputCity;
    private String inputState;
    private String inputCountry;
    private String inputPurpose;
    private String inputHotel;
    
    //Variables for addVisitorInfo method
    private String addZipcode;
    private String addCityName;
    private String addStateName;
    private String addCountryName;
    private String addVisitPurpose;
    private String addHotelInfo;
    private String addNumVisitor;
    private String email;
    
    ///TextBox Field for edit methdos
    private TextField editZip;
    private TextField editCity;
    private TextField editCountry;
    private ComboBox<String> editState;
    private ComboBox<String> editVisitType;
    private ComboBox<String> editNumofVisitor;
    private ComboBox<String> editHotelStay;
    private TextField editVisitDetails;
    private TextField editEmail;
    
    //Variables to set the values in edit visitor text boxes from selected row
    
    private String selectedZip;
    private String selectedCity;
    private String selectedState;
    private String selectedCountry;
    private String selectedVisitType;
    private String selectedNumofVisitor;
    private String selectedHotelStay;
    private String selectedVisitDetails;
    private String selectedEmail;
    
    
    
    //Variables to initialize the values  from selected row for updatebutton
    
    private String updateZip;
    private String updateCity;
    private String updateState;
    private String updateCountry;
    private String updateVisitType;
    private String updateNumofVisitor;
    private String updateHotelStay;
    private String updateVisitDetails;
    private String updateEmail;
    
    private int selectedRowNumber;
   
    
    private ObservableList<Visitors> data;
    
    ////////////////////////
    //For Table in the buttom of the scene
    @FXML
    private TableView<Visitors> myTable;
    
   
    @FXML
    private TableView<Email> tableEmail;
    @FXML
    private TableColumn<Visitors, String> hotelStayColumn;
    @FXML
    private TableColumn<Visitors, String> countryColumn;
    @FXML
    private TableColumn<Visitors, String> purposeColumn;

    @FXML
    private TableColumn<Visitors, String> emailIDColumn;
    
    @FXML
    private TableColumn<Visitors, String> stateColumn;

    @FXML
    private TableColumn<Visitors, String> detailsColumn;
    
    @FXML
    private TableColumn<Visitors, String> cityColumn;

    @FXML
    private TableColumn<Visitors, String> numOfPeopleColumn;

    @FXML
    private TableColumn<Visitors, String> dateTimeColumn;

    @FXML
    private TableColumn<Visitors, String> serialNumberColumn;
    
    @FXML
    private TableColumn<Visitors, String> numVisitorColumn;
    @FXML
    private TableColumn<Visitors, String> zipColumn;
    
   
    
    private String displayInstruction;
    java.util.Date dt = new java.util.Date();
	java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
	 private String currentDate = sdf.format(dt);;
 
    @Override
	public void initialize(URL location, ResourceBundle resources) {
	 topStates(); 
	 pieChartInHome();
	 String query="SELECT city, state, zipCode, country, visitType, visitDetails, numOfVisitors, placeOfStay, email_ID, timestamp "
				+ "FROM VisitorInformation ORDER BY SN DESC";
		importDataFromDBToHomeTable(query);
	 
    }
 
    
    
   public void loadHome(){
	   
	   
    }
 
    public void topStates(){
    	ArrayList<String> stateName = new ArrayList<String>();
    	ArrayList<Integer> visitorNum = new ArrayList<Integer>();
    	int arraylistSize=0;
    	
    		try (Connection connection = myDataBase.getConnection())
    		{
    			
    				String loadQuery = "SELECT state, SUM(numOfVisitors) FROM VisitorInformation GROUP BY state ORDER BY SUM(numOfVisitors) DESC LIMIT 10 ;";
    			
    				Statement stmt = connection.createStatement();
    				
    			  
    			  ResultSet rstate3 ;
    				rstate3=(ResultSet) stmt.executeQuery(loadQuery);
    				while (rstate3.next()){
    					stateName.add(rstate3.getString(1));
    					visitorNum.add(rstate3.getInt(2));
    					}
    				
    				 arraylistSize=stateName.size();
    				
    			
    		}
    		
    		catch (Exception e)
    		{
    				e.printStackTrace();
    		}
    		xAxis.setLabel("State");       
            yAxis.setLabel("Number of Visitors");
    		
    		XYChart.Series series1 = new XYChart.Series();
            series1.setName("2017");
            for (int j=0;j<arraylistSize;j++){
            if (stateName.get(j).equals(null)){
            	break;
            }
            series1.getData().add(new XYChart.Data(stateName.get(j), visitorNum.get(j)));
            }
            bc.getData().addAll(series1);
           
    	}
    public void pieChartInHome(){
    	
    	ArrayList<Integer> list = new ArrayList<Integer>();
    	
    	try (Connection connection = myDataBase.getConnection())
		{
    		String query1= "SELECT SUM(numOfVisitors) FROM VisitorInformation WHERE visitType = \"Business\"";
    		String query2= "SELECT SUM(numOfVisitors) FROM VisitorInformation WHERE visitType = \"Pleasure\"";
    		String query3= "SELECT SUM(numOfVisitors) FROM VisitorInformation WHERE visitType = \"Convention\"";
    		String query4= "SELECT SUM(numOfVisitors) FROM VisitorInformation WHERE visitType <> \"Business\" AND visitType <> \"Pleasure\" AND visitType <> \"Convention\"";
    		
    		Statement stmt = connection.createStatement();
    		
    		ResultSet rs1= stmt.executeQuery(query1);
    		while (rs1.next()){
				
				list.add(rs1.getInt(1));	
			}
    		ResultSet rs2= stmt.executeQuery(query2);
    		while (rs2.next()){
				
				list.add(rs2.getInt(1));	
			}
    		ResultSet rs3= stmt.executeQuery(query3);
    		while (rs3.next()){
				
				list.add(rs3.getInt(1));	
			}
    		ResultSet rs4= stmt.executeQuery(query4);
    		while (rs4.next()){
				
				list.add(rs4.getInt(1));	
			}
    		}
    	catch (Exception e)
		{
				e.printStackTrace();
		}
    	
    	 ObservableList<PieChart.Data> pieChartData =
                 FXCollections.observableArrayList(
                 new PieChart.Data("Business", list.get(0)),
                 new PieChart.Data("Convention",list.get(2)),
                 new PieChart.Data("Other", list.get(3)),
                 new PieChart.Data("Pleasure",list.get(1)));
    	 
    	chart.setData(pieChartData);
    	chart.setTitle("Visit Type");
    	
    }
    
    @FXML
    public void analyzeEmail(ActionEvent event) 
    {
		vBoxForDisplay.getChildren().clear();//remove(bc);
		//myBorderPane.getChildren().remove(scrollPaneForTable);
		scrollPaneForTable.setVisible(false);
		vBoxForDisplay.setPadding(new Insets(10, 50, 80, 50));
        vBoxForDisplay.setSpacing(15);
        
        
        Label action = new Label("Select a range of date.");
        
        startDate = new DatePicker();
    	startDate.setPromptText("Start Date MM/dd/yyyy");
    			
    	endDate = new DatePicker();
    	endDate.setPromptText("End Date  MM/dd/yyyy");
    	
    	enterButton = new Button("Submit");
    	
    	vBoxForDisplay.getChildren().addAll(action, startDate, endDate, enterButton);
    	
    	enterButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
            	exportEmail();
            }
    	});
		
    }
    @FXML
    public void addVisitor(ActionEvent event) 
    {
    	vBoxForDisplay.getChildren().clear();
    	scrollPaneForTable.setVisible(false);
    	vBoxForDisplay.setPadding(new Insets(10, 50, 80, 50));
        vBoxForDisplay.setSpacing(15);
        
        addState= new ComboBox<String>(); //TextField();
    	addState.getItems().addAll("AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY");
    	addState.setPromptText("Select the State");
    	addState.setValue("");
    	addState.setEditable(true);
    	
    	addEmail=new TextField();
    	addEmail.setPrefWidth(200);
    	addEmail.setPrefHeight(40);
    	addEmail.setPromptText("Enter E-mail address");
    	addEmail.setFocusTraversable(false);
    	
    	addCity = new TextField();
    	addCity.setPrefWidth(200);
    	addCity.setPrefHeight(40);
    	addCity.setPromptText("Enter the City");
    	addCity.setFocusTraversable(false);
    	
    	addZip = new TextField();
    	addZip.setPrefWidth(200);
    	addZip.setPrefHeight(40);
    	addZip.setPromptText("Enter the ZipCode");
    	addZip.setFocusTraversable(false);
    	
    	addCountry = new TextField();
    	addCountry.setPrefWidth(200);
    	addCountry.setPrefHeight(40);
    	addCountry.setPromptText("Enter the Country");
    	addCountry.setFocusTraversable(false);
    	
    	addpurpose= new ComboBox<String>();
    	addpurpose.getItems().addAll("Business", "Pleasure","Convention","Other");
    	addpurpose.setPromptText("Purpose Of Visit");
    	addpurpose.setValue("");
    	addpurpose.setEditable(true);
    	
    	addNumofVisitor=new ComboBox<String>();
    	addNumofVisitor.getItems().addAll("1","2","3","4","5","6","7","8","9","10");
    	addNumofVisitor.setPromptText("Number Of Visitor");
    	addNumofVisitor.setValue("");
    	addNumofVisitor.setEditable(true);
    	
    	addHotel = new ComboBox<String>();
    	addHotel.getItems().addAll("Yes","No");
    	addHotel.setPromptText("Staying in Hotel");
    	addHotel.setValue("");
    	addHotel.setEditable(true);
    	
    	addButton = new Button("Add");
    	
    	addLabel=new Label("Please fill the visitor information.");
    	
    	addDate = new DatePicker();
    	addDate.setPromptText("Date of Visit  MM/dd/yyyy");
    	
    	vBoxForDisplay.getChildren().addAll(addLabel,addZip,addCity,addState,addCountry,addEmail,addNumofVisitor,addHotel, addpurpose,addDate, addButton);
    	
    	addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
            	addVisitorInfo();
            	
            }
    	});
    	
    	
    }
    
    
	@FXML
    public void analyzeGeneral(ActionEvent event) 
    {
		createTextBox();
        
    	
    	importCSVButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
            	int check=0;
            	queryAnalysis(check);
            	
            }
        });
    	
    	submitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
            	int check=1;
            queryAnalysis(check);
            }
    	});
    }
    
    private void createTextBox()
    {
    	vBoxForDisplay.getChildren().clear();//remove(bc);
		//myBorderPane.getChildren().remove(scrollPaneForTable);
		scrollPaneForTable.setVisible(false);
		
    	vBoxForDisplay.setPadding(new Insets(10, 50, 80, 50));
        vBoxForDisplay.setSpacing(15);
        
        
        hBoxForDisplay = new HBox();
        
     
        
        StackPane paneCity = new StackPane();
        StackPane paneCity1 = new StackPane();
        
        btnTextClear = new Button("X");
        btnTextClear.setShape(new Circle(0.3));
        btnTextClear.setStyle("-fx-background-color: #00FF80; -fx-margin: 15px; -fx-margin: 15px;");
        btnTextClear.setBackground(null);
        
        btnTextClear1 = new Button("X");
        btnTextClear1.setShape(new Circle(0.3));
        btnTextClear1.setStyle("-fx-background-color: #00FF80; -fx-margin: 15px; -fx-margin: 15px;");
        btnTextClear1.setBackground(null);
        
    	//Create a TextField to ask admin to enter city
    	txtFieldZip = new TextField();
    	txtFieldZip.setPrefWidth(300);
    	txtFieldZip.setPrefHeight(40);
    	txtFieldZip.setPromptText("Enter the ZipCode");
    	txtFieldZip.setFocusTraversable(false);
    	
    	
    	txtFieldCity = new TextField();
    	txtFieldCity.setPrefWidth(300);
    	txtFieldCity.setPrefHeight(40);
    	txtFieldCity.setPromptText("Enter the City");
    	txtFieldCity.setFocusTraversable(false);
    	
    	
    	txtFieldState= new ComboBox<String>(); //TextField();
    	txtFieldState.getItems().addAll("AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY");
    	txtFieldState.setPromptText("Select the State");
    	txtFieldState.setValue("");
    	txtFieldState.setEditable(true);
    	//txtFieldState.getSelectionModel().clearSelection();
    	/**txtFieldState = new TextField();
    	txtFieldState.setPrefWidth(300);
    	txtFieldState.setPrefHeight(40);
    	txtFieldState.setPromptText("Enter the State");
    	txtFieldState.setFocusTraversable(false);*/
    //	ALAKAZARCACOCTDEFLGAHIIDILINIAKSKYLAMEMDMAMIMNMSMOMTNENVNHNJNMNYNCNDOHOKORPARISCSDTNTXUTVTVAWAWVWIWY
    	
    	
    	txtFieldCountry = new TextField();
    	txtFieldCountry.setPrefWidth(300);
    	txtFieldCountry.setPrefHeight(40);
    	txtFieldCountry.setPromptText("Enter the Country");
    	txtFieldCountry.setFocusTraversable(false);
    	
   
        purpose= new ComboBox<String>();
    	purpose.getItems().addAll("Business", "Pleasure","Convention","Other");
    	purpose.setPromptText("Purpose Of Visit");
    	purpose.setValue("");
    	purpose.setEditable(true);
    	    
     
    	
    	txtFieldHotelstay = new ComboBox<String>();
    	txtFieldHotelstay.getItems().addAll("Yes","No");
    	txtFieldHotelstay.setPromptText("Staying in Hotel");
    	txtFieldHotelstay.setValue("");
    	txtFieldHotelstay.setEditable(true);
    	
    	paneCity.getChildren().addAll(txtFieldZip,btnTextClear);
    	btnTextClear.visibleProperty().bind( txtFieldZip.textProperty().isEmpty().not() );
    	paneCity.setAlignment(btnTextClear,Pos.CENTER_RIGHT);
    	paneCity.setMargin(btnTextClear, new Insets(5, 5, 5, 5));
    	
   /** 	paneCity1.getChildren().addAll(txtFieldCountry,btnTextClear);
    	btnTextClear1.visibleProperty().bind( txtFieldCountry.textProperty().isEmpty().not() );
    	paneCity1.setAlignment(btnTextClear,Pos.CENTER_RIGHT);
    	paneCity1.setMargin(btnTextClear, new Insets(5, 5, 5, 5));
    	*/
    	
    	
    	labelStartDate = new TextField("Enter the start date");
    	hBoxForDisplay.getChildren().add(paneCity);
    	
    	
    	startDate = new DatePicker();
    	startDate.setPromptText("Start Date MM/dd/yyyy");
    			
    	endDate = new DatePicker();
    	endDate.setPromptText("End Date  MM/dd/yyyy");
    	
    	labelDisplay = new Label(displayInstruction);
    	
    	
    	
    	submitButton = new Button("Submit");
    	importCSVButton = new Button("Generate CSV");
    	
    	vBoxForDisplay.getChildren().addAll(hBoxForDisplay,txtFieldCity, txtFieldState,txtFieldCountry,txtFieldHotelstay,purpose, startDate,endDate,submitButton,importCSVButton,labelDisplay);
    	
    	
    	btnTextClear.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                txtFieldZip.setText("");
                txtFieldZip.requestFocus();
            }
        });	
    	
    }
    
    //This method will edit the visitor information. First, a row will be selected from table
	//the information will be loaded to the forms including text field and other.
	//Will hit the Update button, and a dialog box will appear to ask admin if they want to change
	//Will update the information of the visitor in the database
	@FXML
	public void editVisitorSelectedInTable(ActionEvent event) 
	{
		vBoxForDisplay.getChildren().remove(bc);
		myBorderPane.getChildren().remove(scrollPaneForTable);
		vBoxForDisplay.getChildren().clear();
		editInterface();
		
		
		vBoxForDisplay.getChildren().add(scrollPaneForTable);
		String query="SELECT city, state, zipCode, country, visitType, visitDetails, numOfVisitors, placeOfStay, email_ID, timestamp "
				+ "FROM VisitorInformation ORDER BY SN DESC";
		importDataFromDBToHomeTable(query);


		//////////////
		//String selected = myTable.getId();
		//int selected = myTable.getSelectionModel().getSelectedIndex();

		//System.out.println(selected);
		/////////////
	}

	@FXML
	private void mouseClickedUpdateInformation(MouseEvent event) 
	{
		selectedRowNumber = myTable.getSelectionModel().getSelectedIndex() + 1;
		Visitors selected =myTable.getSelectionModel().getSelectedItem();
		
		selectedZip=selected.getZipCode();
		selectedCity=selected.getCity();
		selectedState=selected.getStateName();
		selectedCountry=selected.getCountry();
		selectedVisitType=selected.getVisitType();
		selectedNumofVisitor=selected.getNumOfVisitors();
		selectedHotelStay=selected.getPlaceOfStay();
		selectedVisitDetails=selected.getVisitDetails();
		selectedEmail=selected.getEmail_ID();
			
	}	
		/* * ALTER TABLE LoginInformation.UserInformation DROP SN;
		   ALTER TABLE LoginInformation.UserInformation ADD SN MediumINT NOT NULL AUTO_INCREMENT Primary key First;
		   */
	public void editInterface(){
		Label label1 = new Label("Zipcode:");
		editZip = new TextField ();
		
		Label label2 = new Label("City:");
		editCity = new TextField ();
		
		Label label3 = new Label("State");
		editState = new ComboBox<String>();
		editState.getItems().addAll("AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY");
		editState.setEditable(true);
		
		Label label4 = new Label ("Country:");
		editCountry = new TextField();
		
		Label label5 = new Label ("Visit Type:");
		editVisitType = new ComboBox<String>();
		editVisitType.getItems().addAll("Business", "Pleasure","Convention","Other");
		editVisitType.setEditable(true);
		
		Label label6 = new Label (" Number of Visitors:");
		editNumofVisitor = new ComboBox<String>();
		editNumofVisitor.getItems().addAll("1","2","3","4","5","6","7","8","9","10");
		editNumofVisitor.setEditable(true);
		
		Label label7 = new Label ("Staying in Hotel:");
		editHotelStay = new ComboBox<String>();
		editHotelStay.getItems().addAll("Yes","No");
		editHotelStay.setEditable(true);
		
		Label label8 = new Label ("VisitDetails:");
		editVisitDetails = new TextField();
		
		Label label9 = new Label ("E-mail Address:");
		editEmail =new TextField();
		
		
		
		
		
		editButton = new Button("Select");
		updateButton = new Button("Update");
		
		
		HBox hb1 = new HBox();
		hb1.getChildren().addAll(label1,editZip,label2,editCity);
		
		VBox hb = new VBox();
		hb.getChildren().addAll(hb1,label3,editState,label4,editCountry,label5,editVisitType,label8,editVisitDetails, label6, editNumofVisitor,label7,editHotelStay,label9,editEmail, editButton,updateButton);
		hb.setSpacing(10);
		
	vBoxForDisplay.getChildren().add(hb);
	
	editButton.setOnAction(new EventHandler<ActionEvent>() {
        @Override public void handle(ActionEvent e) {
        	
        	editZip.setText(selectedZip);
        	editCity.setText(selectedCity);
        	editState.setValue(selectedState);
        	editCountry.setText(selectedCountry);
        	editVisitType.setValue(selectedVisitType);
        	editVisitDetails.setText(selectedVisitDetails);
        	editEmail.setText(selectedEmail);
        	editNumofVisitor.setValue(selectedNumofVisitor);
        	editHotelStay.setValue(selectedHotelStay);
        }
	});
	
	updateButton.setOnAction(new EventHandler<ActionEvent>() {
        @Override public void handle(ActionEvent e) {
        	   updateZip=editZip.getText();
        	   updateCity=editCity.getText();
        	   updateState=editState.getValue();
        	   updateCountry=editCountry.getText();
        	   updateVisitType=editVisitType.getValue();
        	   updateNumofVisitor=editNumofVisitor.getValue();
        	   updateHotelStay=editHotelStay.getValue();
        	   updateVisitDetails=editVisitDetails.getText();
        	   updateEmail=editEmail.getText();
        	try{
        		
        		
        		 Connection conn = DBConnection.connect();
        		 
        		 String updateQuery="UPDATE VisitorInformation SET zipCode= '"+updateZip+"' , city='"+updateCity+"',state='"+updateState+"', country='"+updateCountry+"',visitType='"+updateVisitType+"',numOfVisitors='"+updateNumofVisitor+"',visitDetails='"+updateVisitDetails+"',placeOfStay='"+updateHotelStay+"',email_ID='"+updateEmail+"' WHERE SN=413";
        		
        		 Statement stmt = conn.createStatement();
    				stmt.executeUpdate(updateQuery);
    				
    				editVisitorSelectedInTable(e);
    				
    				
    				
        	}
        	catch (SQLException e1) {
    			// TODO Auto-generated catch block
    			e1.printStackTrace();
    		}
        }
	});
		
		
		
		 
	}

    @FXML
    private void clearTextFieldByClickBtn(ActionEvent event) 
    {
    	
    }
    
    public void exportAsCSV(String read){
    	String filename=currentDate+" Report.csv";
    	
    	try (Connection connection = DBConnection.getConnection())
    	{
    		FileWriter fw = new FileWriter(filename);	
    	
    		Statement stmt = connection.createStatement();
    	ResultSet rstate2 ;
    	rstate2=(ResultSet) stmt.executeQuery(read);
    	
    	fw.append("City");
        fw.append(',');
        fw.append("State");
        fw.append(',');
        fw.append("Zip Code");
        fw.append(',');
        fw.append("Country");
        fw.append(',');
        fw.append("Type of Visit");
        fw.append(',');
        fw.append("Visit Details");
        fw.append(',');
        fw.append("Number of Visitors");
        fw.append(',');
        fw.append("Staying in Hotel");
        fw.append(',');
        fw.append("Email");
        fw.append(',');
        fw.append("Date & Time");
        fw.append('\n');
        
     while (rstate2.next()){
    	
            fw.append(rstate2.getString(1));
            fw.append(',');
            fw.append(rstate2.getString(2));
            fw.append(',');
            fw.append(rstate2.getString(3));
            fw.append(',');
            fw.append(rstate2.getString(4));
            fw.append(',');
            fw.append(rstate2.getString(5));
            fw.append(',');
            fw.append(rstate2.getString(6));
            fw.append(',');
            fw.append(rstate2.getString(7));
            fw.append(',');
            fw.append(rstate2.getString(8));
            fw.append(',');
            fw.append(rstate2.getString(9));
            fw.append(',');
            fw.append(rstate2.getString(10));
          
            fw.append('\n');
           }
        fw.flush();
        fw.close();
    	}
    	catch (Exception e)
    	{
    			e.printStackTrace();
    	}
    	
    	
    }
    
  
    
    private void queryAnalysis(int check) {
    	vBoxForDisplay.getChildren().remove(bc);
    	scrollPaneForTable.setVisible(true);
    	
    	
    
    	
    	inputZipCode = txtFieldZip.getText();
    	inputCity=txtFieldCity.getText();
    	
    	inputState=txtFieldState.getValue();
    	inputCountry=txtFieldCountry.getText();
    	
    	inputPurpose=purpose.getValue();
    	
    	inputHotel=txtFieldHotelstay.getValue();
    	
    	

    	try {
    		
    		LocalDate startDateValue = startDate.getValue();
    		
    		
    		LocalDate endDateValue = endDate.getValue();
    		
    		
    		
    		 Connection conn = myDataBase.connect();
             data = FXCollections.observableArrayList();
             ResultSet rs = null;
             
             //Query to run for analysis
             String analyzeQuery = "";
             // Execute query and store result in a resultset with matching input conditions
             if (startDateValue==null || endDateValue==null){
            	 
            	 analyzeQuery = "SELECT city, state,zipCode, country, visitType, VisitDetails, numOfVisitors, placeOfStay, email_ID, timestamp FROM VisitorInformation WHERE ";
            	 
            	if (!inputZipCode.equals(""))
            	 {
            	 analyzeQuery += "zipCode =  '"+inputZipCode+"' ";
            	// System.out.println(inputPurpose);
            	 }
            	 
            	if (!inputCity.equals(""))
            	{
            		if (inputZipCode.equals(""))
            		{
            		analyzeQuery += "city = '"+inputCity+"' ";
            		}
            		else if (!inputZipCode.equals(""))
            		{
            			analyzeQuery += "AND city = '"+inputCity+"' ";
            		}
            	}
            	
            	if (!inputState.equals(""))
            	{
            		if (inputZipCode.equals("") && inputCity.equals("")){
            			analyzeQuery += "state = '"+inputState+"' ";
            		}
            		else if (!inputZipCode.equals("") || !inputCity.equals(""))
            		{
            			analyzeQuery += "AND state = '"+inputState+"' ";
            		}
            		
            	}
            	
            	if (!inputCountry.equals(""))
            	{
            		if (inputZipCode.equals("") && inputCity.equals("") && inputState.equals(""))
            		{
            		analyzeQuery += "country ='"+inputCountry+"' ";
            		}
            		else if (!inputZipCode.equals("") || !inputCity.equals("") || !inputState.equals(""))
            		{
            		analyzeQuery += "AND country = '"+inputCountry+"' ";
            		}

            	}
            	
           	if(!inputPurpose.equals(""))
            	{
            		if (inputZipCode.equals("") && inputCity.equals("") && inputState.equals("") && inputCountry.equals(""))
            		{
            			analyzeQuery += "visitType = '"+inputPurpose+"' ";
            		}
            		else if (!inputZipCode.equals("") || !inputCity.equals("") || !inputState.equals("") || !inputCountry.equals(""))
            		{
            			analyzeQuery += " AND visitType = '"+inputPurpose+"' ";
            		}
            	}
            	
            	if(!inputHotel.equals(""))
            	{
            		if (inputZipCode.equals("") && inputCity.equals("") && inputState.equals("") && inputCountry.equals("") && inputPurpose.equals(""))
            		{
            			analyzeQuery +="placeOfStay = '"+inputHotel+"' ";
            		}
            		else if (!inputZipCode.equals("") || !inputCity.equals("") || !inputState.equals("") || !inputCountry.equals(""))
            		{
            			analyzeQuery += " AND placeOfStay = '"+inputHotel+"' ";
            		}
            	}
            	

            //	rs = conn.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE).executeQuery(analyzeQuery);
             }
             
             
             
             else if (!startDate.equals("") && !endDate.equals(""))
             {
            	 analyzeQuery ="SELECT city, state,zipCode, country, visitType, VisitDetails, numOfVisitors, placeOfStay, email_ID, timestamp FROM VisitorInformation WHERE timestamp >= '"+startDateValue+"' AND timestamp <= '"+endDateValue+"'" ;
             
            	 if (!inputZipCode.equals(""))
            	 {
            	 analyzeQuery += " AND zipCode =  '"+inputZipCode+"' ";
            	 }
            	 
            	if (!inputCity.equals(""))
            	{
            		
            		analyzeQuery += " AND city = '"+inputCity+"' ";
            	}
            	
            	if (!inputState.equals(""))
            	{

            			analyzeQuery += " AND state = '"+inputState+"' ";
          
            	}
            	
            	if (!inputCountry.equals(""))
            	{

            		analyzeQuery += " AND country = '"+inputCountry+"' ";

            	}
            	 
            	if (!inputPurpose.equals(""))
            	{

            		analyzeQuery += " AND visitType = '"+inputPurpose+"' ";

            	}
            	if (!inputHotel.equals(""))
            	{

            		analyzeQuery += " AND placeOfStay = '"+inputHotel+"' ";

            	}
            	 
            	 
            	// rs = conn.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE).executeQuery(analyzeQuery);
   
             }
             
             
             importDataFromDBToHomeTable(analyzeQuery);
          /**   int serialNumber=1;
             
           
             myTable.setItems(null);
             while (rs.next()) {
                 //get string from db,whichever way 
                 data.add(new Visitors(serialNumber, rs.getString(1),rs.getString(2),  rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10)));
    	
    		
                 serialNumberColumn.setCellValueFactory(new PropertyValueFactory<>("serialNumber"));
                 cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
                 stateColumn.setCellValueFactory(new PropertyValueFactory<>("stateName"));
                 zipColumn.setCellValueFactory(new PropertyValueFactory<>("zipCode"));
                 countryColumn.setCellValueFactory(new PropertyValueFactory<>("country"));
                 purposeColumn.setCellValueFactory(new PropertyValueFactory<>("visitType"));
                 detailsColumn.setCellValueFactory(new PropertyValueFactory<>("VisitDetails"));
                 numVisitorColumn.setCellValueFactory(new PropertyValueFactory<>("numOfVisitors"));
                 hotelStayColumn.setCellValueFactory(new PropertyValueFactory<>("placeOfStay"));
                 emailIDColumn.setCellValueFactory(new PropertyValueFactory<>("email_ID"));
                 dateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));
               
                 
                
                 
                
                 myTable.setItems(data);
               
                 serialNumber++;

    		
             }	
           */
             
             if (check==0){
         		exportAsCSV(analyzeQuery);
         	}
    		
			
             
    	}
		 catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
  
    } 
    
    private void importDataFromDBToHomeTable(String dbQuery)
	{
		try (Connection connection = myDataBase.getConnection())
		{
			Connection conn = myDataBase.connect();
			data = FXCollections.observableArrayList();
			ResultSet rs = null;
			// Execute query and store result in a resultset

			rs = conn.createStatement().executeQuery(dbQuery);

			int serialNumber = 1;
			myTable.setItems(null);
			while (rs.next()) 
			{
				//get string from db,whichever way 
				data.add(new Visitors(serialNumber, rs.getString(1),rs.getString(2),  rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),
						rs.getString(8),rs.getString(9),rs.getString(10)));


				serialNumberColumn.setCellValueFactory(new PropertyValueFactory<>("serialNumber"));
				cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
				stateColumn.setCellValueFactory(new PropertyValueFactory<>("stateName"));
				zipColumn.setCellValueFactory(new PropertyValueFactory<>("zipCode"));
				countryColumn.setCellValueFactory(new PropertyValueFactory<>("country"));
				purposeColumn.setCellValueFactory(new PropertyValueFactory<>("visitType"));
				detailsColumn.setCellValueFactory(new PropertyValueFactory<>("VisitDetails"));
				numVisitorColumn.setCellValueFactory(new PropertyValueFactory<>("numOfVisitors"));
				hotelStayColumn.setCellValueFactory(new PropertyValueFactory<>("placeOfStay"));
				emailIDColumn.setCellValueFactory(new PropertyValueFactory<>("email_ID"));
				dateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));

				
				myTable.setItems(data);
				serialNumber++;
			}
		}

		catch (Exception e)
		{
			e.printStackTrace();
		}

	}
    
    
    private void exportEmail() {
		String filename = currentDate+" Email List.csv";
        try {
        	
        	LocalDate startDateValue = startDate.getValue();
        	LocalDate endDateValue = endDate.getValue();
        	
        	
            FileWriter fw = new FileWriter(filename);
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logininformation", "root", "root");
            String query = "select distinct email_ID from VisitorInformation WHERE timestamp >= '"+startDateValue+"' AND timestamp <= '"+endDateValue+"'" ;
            Statement stmt = conn.createStatement();
            ResultSet rs = (ResultSet)stmt.executeQuery(query);
            fw.append("Email list");
            fw.append('\n');
            while (rs.next()) {
             
             fw.append(rs.getString(1));
             fw.append('\n');
               }
            fw.flush();
            fw.close();
            conn.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
       // emailTable();
	
		      
	}
    
    private void addVisitorInfo(){
    	
    	addZipcode=addZip.getText();
    	addCityName=addCity.getText();
    	addStateName=addState.getValue();
    	addCountryName=addCountry.getText();
    	addVisitPurpose=addpurpose.getValue();
    	addHotelInfo=addHotel.getValue();
    	email=addEmail.getText();
    	addNumVisitor=addNumofVisitor.getValue();
    	
    	if(addNumVisitor.equals("")){
    		addNumVisitor="1";
    	}
    	
    	java.util.Date dt = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String currentDate = sdf.format(dt);;
		
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        //convert String to LocalDate
		LocalDate localDate = LocalDate.parse(currentDate, formatter);
		
    	
    	try{
    		LocalDate DateValue = addDate.getValue();
    		if (DateValue==null)
    		{
    			DateValue= localDate;
    		}
    		
    		 Connection conn = DBConnection.connect();
    		 
    		 String addQuery="INSERT INTO VisitorInformation (zipCode,city,state,country,visitType,numOfVisitors,placeOfStay,email_ID,timestamp) VALUES ('"+addZipcode+"','"+addCityName+"','"+addStateName+"','"+addCountryName+"','"+addVisitPurpose+"','"+addNumVisitor+"','"+addHotelInfo+"','"+email+"','"+DateValue+"')";
    		 
    		
    		 Statement stmt = conn.createStatement();
				stmt.executeUpdate(addQuery);
				
				System.out.println("Saved to the database!");
    	}
    	catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
    	
    	
    }
    
    private void emailTable(){
    	
    	final Label label = new Label("Email List");
    	label.setFont(new Font("Arial", 20));
    	
    	 TableColumn SNCol = new TableColumn("SN");
         TableColumn emailCol = new TableColumn("Email");
         TableColumn DateCol = new TableColumn("Date");
    	
         tableEmail.getColumns().addAll(SNCol, emailCol, DateCol);
         
    	
    }

    	
    
    }

	
		
	
	


