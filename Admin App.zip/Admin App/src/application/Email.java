package application;
import javafx.beans.property.StringProperty;


public class Email {
	private int serialNumber;
	private String email_ID;
	private String timestamp;
	
	
	public Email(int serialNumber,String email_ID,String timestamp){
		super();
		this.serialNumber = serialNumber;
		this.email_ID = email_ID;
		this.timestamp=timestamp;
	}
	public int getSerialNumber() {
		return serialNumber;
	}


	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}


	public String getEmail_ID() {
		return email_ID;
	}


	public void setEmail_ID(String email_ID) {
		this.email_ID = email_ID;
	}


	public String getTimestamp() {
		return timestamp;
	}


	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}



}
