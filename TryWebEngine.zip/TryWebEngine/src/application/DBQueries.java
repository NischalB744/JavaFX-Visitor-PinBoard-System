package application;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Connection;

public class DBQueries {
	
	public String analyzeDataFromDb() throws ClassNotFoundException, SQLException{
		String cityQuery = "SELECT city FROM UserInformation where email_ID = 'thapaasanjay@gmail.com';";
		Connection dbCon = (Connection) DBConnection.getConnection();
		Statement stmt = dbCon.createStatement();
		//stmt.executeUpdate(cityQuery);
		
		System.out.println("Saved to the database!");
		ResultSet rs2=stmt.executeQuery(cityQuery);
		String lastRowMonth = "";
		while (rs2.next()) {
		    
		        lastRowMonth = rs2.getString(1);
		        //System.out.println(lastRowMonth);
		    
		  
		}
		//System.out.println(lastRowMonth);
		
		return lastRowMonth;
	}

}
