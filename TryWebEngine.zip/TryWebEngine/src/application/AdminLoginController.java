package application;

import java.io.FileWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import com.sun.prism.paint.Color;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.SwipeEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class AdminLoginController<myBorderPane> implements Initializable
 {
	@FXML
    private MenuItem menuItemByDate;

    @FXML
    private MenuItem menuItemZipCode;
    
    @FXML
    private BorderPane myBorderPane;
    
    @FXML
    private MenuBar myMenuBar;
    
    @FXML
    private VBox vBoxForDisplay;
    
    @FXML
    private Button submitAnalysis;
    
    @FXML
    private Button btnTextClear;
    
    @FXML
    private TextField txtFieldZip;
    @FXML
    private    TextField/**ComboBox<String> */txtFieldState;
    @FXML
    private TextField txtFieldCity;
    @FXML
    private TextField txtFieldCountry;
    @FXML
    private HBox hotel;
    @FXML
    private TextField/**ComboBox<String>*/ purpose;
    @FXML
    private TextField txtFieldHotelstay;
    @FXML
    private Label labelShowAnalysis;
    
    @FXML
    private TextField labelStartDate;
    
    @FXML 
    private HBox hBoxForDisplay;
    
    /////////////////////////
    @FXML
    private BarChart<String, Integer> bc;

    @FXML
    private NumberAxis yAxis;

    @FXML
    private CategoryAxis xAxis;
    
    //////////////////////
    @FXML
    private Button submitButton;
    
    @FXML
    private Button enterButton;
    
    @FXML
    private Button importCSVButton;
    
    @FXML
    private DatePicker startDate;
    
    @FXML
    private DatePicker endDate;
    
    @FXML
    private ScrollPane scrollPaneForTable;
    /////////////////////
    DBConnection myDataBase = new DBConnection();
    
   
    
    //To initializing the variables for gettting input
    private String inputZipCode;
    private String inputCity;
    private String inputState;
    private String inputCountry;
    private String inputPurpose;
    private String inputHotel;
    
    private ObservableList<Visitors> data;
    
    ////////////////////////
    //For Table in the buttom of the scene
    @FXML
    private TableView<Visitors> myTable;
    @FXML
    private TableColumn<Visitors, String> hotelStayColumn;
    @FXML
    private TableColumn<Visitors, String> countryColumn;
    @FXML
    private TableColumn<Visitors, String> purposeColumn;

    @FXML
    private TableColumn<Visitors, String> emailIDColumn;

    @FXML
    private TableColumn<Visitors, String> stateColumn;

    @FXML
    private TableColumn<Visitors, String> detailsColumn;
    
    @FXML
    private TableColumn<Visitors, String> cityColumn;

    @FXML
    private TableColumn<Visitors, String> numOfPeopleColumn;

    @FXML
    private TableColumn<Visitors, String> dateTimeColumn;

    @FXML
    private TableColumn<Visitors, String> serialNumberColumn;
    
    @FXML
    private TableColumn<Visitors, String> numVisitorColumn;
    @FXML
    private TableColumn<Visitors, String> zipColumn;
    
    
    java.util.Date dt = new java.util.Date();
	java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
	 private String currentDate = sdf.format(dt);;
 
    @Override
	public void initialize(URL location, ResourceBundle resources) {
	 topStates(); 
	 
    }
 
 
    public void topStates(){
    	ArrayList<String> stateName = new ArrayList<String>();
    	ArrayList<Integer> visitorNum = new ArrayList<Integer>();
    	int arraylistSize=0;
    	
    		try (Connection connection = myDataBase.getConnection())
    		{
    			
    				String loadQuery = "SELECT state, SUM(numOfVisitors) FROM VisitorInformation GROUP BY state ORDER BY SUM(numOfVisitors) DESC LIMIT 10 ;";
    			
    				Statement stmt = connection.createStatement();
    				
    			  
    			  ResultSet rstate3 ;
    				rstate3=(ResultSet) stmt.executeQuery(loadQuery);
    				while (rstate3.next()){
    					stateName.add(rstate3.getString(1));
    					visitorNum.add(rstate3.getInt(2));
    					}
    				
    				 arraylistSize=stateName.size();
    				
    			
    		}
    		
    		catch (Exception e)
    		{
    				e.printStackTrace();
    		}
    		xAxis.setLabel("State");       
            yAxis.setLabel("Number of Visitors");
    		
    		XYChart.Series series1 = new XYChart.Series();
            series1.setName("2017");
            for (int j=0;j<arraylistSize;j++){
            if (stateName.get(j).equals(null)){
            	break;
            }
            series1.getData().add(new XYChart.Data(stateName.get(j), visitorNum.get(j)));
            }
            bc.getData().addAll(series1);
           
    	}
    @FXML
    public void analyzeEmail(ActionEvent event) 
    {
		vBoxForDisplay.getChildren().remove(bc);
		//myBorderPane.getChildren().remove(scrollPaneForTable);
		scrollPaneForTable.setVisible(false);
		vBoxForDisplay.setPadding(new Insets(10, 50, 80, 50));
        vBoxForDisplay.setSpacing(15);
        
        
        Label action = new Label("Select a range of date.");
        
        startDate = new DatePicker();
    	startDate.setPromptText("Start Date MM/dd/yyyy");
    			
    	endDate = new DatePicker();
    	endDate.setPromptText("End Date  MM/dd/yyyy");
    	
    	enterButton = new Button("Submit");
    	
    	vBoxForDisplay.getChildren().addAll(action, startDate, endDate, enterButton);
    	
    	enterButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
            	exportEmail();
            }
    	});
		
    }
	@FXML
    public void analyzeGeneral(ActionEvent event) 
    {
		vBoxForDisplay.getChildren().remove(bc);
		//myBorderPane.getChildren().remove(scrollPaneForTable);
		scrollPaneForTable.setVisible(false);
		
    	vBoxForDisplay.setPadding(new Insets(10, 50, 80, 50));
        vBoxForDisplay.setSpacing(15);
        
        
        hBoxForDisplay = new HBox();
        
     
        
        StackPane paneCity = new StackPane();
        
        btnTextClear = new Button("X");
        btnTextClear.setShape(new Circle(0.3));
        btnTextClear.setStyle("-fx-background-color: #00FF80; -fx-margin: 15px; -fx-margin: 15px;");
       
        btnTextClear.setBackground(null);
        
        
    	//Create a TextField to ask admin to enter city
    	txtFieldZip = new TextField();
    	txtFieldZip.setPrefWidth(300);
    	txtFieldZip.setPrefHeight(40);
    	txtFieldZip.setPromptText("Enter the ZipCode");
    	txtFieldZip.setFocusTraversable(false);
    	
    	txtFieldCity = new TextField();
    	txtFieldCity.setPrefWidth(300);
    	txtFieldCity.setPrefHeight(40);
    	txtFieldCity.setPromptText("Enter the City");
    	txtFieldCity.setFocusTraversable(false);
    	
    	
    	txtFieldState= new TextField();//ComboBox<String>();
    	/*txtFieldState.getItems().addAll("","AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY");
    	txtFieldState.setPromptText("Select the State");
    	//txtFieldState.setValue("");
    	txtFieldState.setEditable(true);
    	//txtFieldState.getSelectionModel().clearSelection();
*/    	txtFieldState = new TextField();
    	txtFieldState.setPrefWidth(300);
    	txtFieldState.setPrefHeight(40);
    	txtFieldState.setPromptText("Enter the State");
    	txtFieldState.setFocusTraversable(false);
    //	ALAKAZARCACOCTDEFLGAHIIDILINIAKSKYLAMEMDMAMIMNMSMOMTNENVNHNJNMNYNCNDOHOKORPARISCSDTNTXUTVTVAWAWVWIWY
    	
    	
    	txtFieldCountry = new TextField();
    	txtFieldCountry.setPrefWidth(300);
    	txtFieldCountry.setPrefHeight(40);
    	txtFieldCountry.setPromptText("Enter the Country");
    	txtFieldCountry.setFocusTraversable(false);
    	
   
    /*	purpose= new ComboBox<String>();
    	purpose.getItems().addAll("","Business", "Casual","Other");
    	purpose.setPromptText("Purpose Of Visit");
    	purpose.setValue("");
    	purpose.setEditable(true);*/ 
    	    
        purpose = new TextField();
    	purpose.setPrefWidth(300);
    	purpose.setPrefHeight(40);
    	purpose.setPromptText("Enter the Purpose");
    	purpose.setFocusTraversable(false);
    	
        
    	
    	hotel =new HBox();
    	final ToggleGroup group = new ToggleGroup();
        Label hotelStay=new Label("Hotel Stay");
        
    	RadioButton yes = new RadioButton("Yes");
    	yes.setToggleGroup(group);
    	
    	RadioButton no = new RadioButton("No");
    	no.setToggleGroup(group);
    	
    	hotel.getChildren().addAll(hotelStay,yes,no);
    	
    
    	paneCity.getChildren().addAll(txtFieldZip,btnTextClear);
    	btnTextClear.visibleProperty().bind( txtFieldZip.textProperty().isEmpty().not() );
    	paneCity.setAlignment(btnTextClear,Pos.CENTER_RIGHT);
    	paneCity.setMargin(btnTextClear, new Insets(5, 5, 5, 5));
    	
    	
    	labelStartDate = new TextField("Enter the start date");
    	hBoxForDisplay.getChildren().add(paneCity);
    	
    	
    	startDate = new DatePicker();
    	startDate.setPromptText("Start Date MM/dd/yyyy");
    			
    	endDate = new DatePicker();
    	endDate.setPromptText("End Date  MM/dd/yyyy");
    	
    	
    	submitButton = new Button("Submit");
    	importCSVButton = new Button("Generate CSV");
    	
    	vBoxForDisplay.getChildren().addAll(hBoxForDisplay,txtFieldCity, txtFieldState,txtFieldCountry,hotel,purpose, startDate,endDate,submitButton,importCSVButton);
    	
    	
    	btnTextClear.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                txtFieldZip.setText("");
                txtFieldZip.requestFocus();
            }
        });
        
    	
    	importCSVButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
            	int check=0;
            	queryAnalysis(check);
            	
            }
        });
    	
    	submitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
            	int check=1;
            queryAnalysis(check);
            }
    	});
    }
    
    public void analyzeDataFromDb(ActionEvent event)
    {
    	
    	
    }
    
    

    @FXML
    private void clearTextFieldByClickBtn(ActionEvent event) 
    {
    	
    }
    
    public void exportAsCSV(String read){
    	String filename="Check.csv";
    	
    	try (Connection connection = DBConnection.getConnection())
    	{
    		FileWriter fw = new FileWriter(filename);	
    	
    		Statement stmt = connection.createStatement();
    	ResultSet rstate2 ;
    	rstate2=(ResultSet) stmt.executeQuery(read);
     while (rstate2.next()){
    	
            fw.append(rstate2.getString(1));
            fw.append(',');
            fw.append(rstate2.getString(2));
            fw.append(',');
            fw.append(rstate2.getString(3));
            fw.append(',');
            fw.append(rstate2.getString(4));
            fw.append(',');
            fw.append(rstate2.getString(5));
            fw.append(',');
            fw.append(rstate2.getString(6));
            fw.append(',');
            fw.append(rstate2.getString(7));
            fw.append(',');
            fw.append(rstate2.getString(8));
            fw.append(',');
            fw.append(rstate2.getString(9));
            fw.append(',');
            fw.append(rstate2.getString(10));
          
            fw.append('\n');
           }
        fw.flush();
        fw.close();
    	}
    	catch (Exception e)
    	{
    			e.printStackTrace();
    	}
    	
    	
    }
    
    private void queryAnalysis(int check) {
    	vBoxForDisplay.getChildren().remove(bc);
    	scrollPaneForTable.setVisible(true);
    	
    	
    //	txtFieldState.getSelectionModel().clearSelection();
       //txtFieldState.getItems().clear();

     //   purpose.getSelectionModel().clearSelection();
        //purpose.getItems().clear();
    	
    	inputZipCode = txtFieldZip.getText();
    	inputCity=txtFieldCity.getText();
    	inputState=txtFieldState.getText();
    	//inputState=txtFieldState.getValue();
    	inputCountry=txtFieldCountry.getText();
    	inputPurpose=purpose.getText();
    	//inputPurpose=purpose.getValue();
    	//inputPurpose=group1.getSelectedToggle().getUserData().toString();
    	//inputHotel=txtFieldHotelstay.getText();
    	
    	//System.out.println(inputCountry);
    	try {
    		//////////////////////
    		
    		LocalDate startDateValue = startDate.getValue();
    		System.out.println(startDateValue);
    		
    		LocalDate endDateValue = endDate.getValue();
    		System.out.println(startDateValue);
    		//startDateValue.co
    		//////////////////////
    		
    		 Connection conn = myDataBase.connect();
             data = FXCollections.observableArrayList();
             ResultSet rs = null;
             
             //Query to run for analysis
             String analyzeQuery = "";
             // Execute query and store result in a resultset with matching input conditions
             if (startDateValue==null || endDateValue==null){
            	 
            	 analyzeQuery = "SELECT city, state,zipCode, country, visitType, VisitDetails, numOfVisitors, placeOfStay, email_ID, timestamp FROM VisitorInformation WHERE ";
            	 
            	if (!inputZipCode.equals(""))
            	 {
            	 analyzeQuery += "zipCode =  '"+inputZipCode+"' ";
            	// System.out.println(inputPurpose);
            	 }
            	 
            	if (!inputCity.equals(""))
            	{
            		if (inputZipCode.equals(""))
            		{
            		analyzeQuery += "city = '"+inputCity+"' ";
            		}
            		else if (!inputZipCode.equals(""))
            		{
            			analyzeQuery += "AND city = '"+inputCity+"' ";
            		}
            	}
            	
            	if (!inputState.equals(""))
            	{
            		if (inputZipCode.equals("") && inputCity.equals("")){
            			analyzeQuery += "state = '"+inputState+"' ";
            		}
            		else if (!inputZipCode.equals("") || !inputCity.equals(""))
            		{
            			analyzeQuery += "AND state = '"+inputState+"' ";
            		}
            		
            	}
            	
            	if (!inputCountry.equals(""))
            	{
            		if (inputZipCode.equals("") && inputCity.equals("") && inputState.equals(""))
            		{
            		analyzeQuery += "country ='"+inputCountry+"' ";
            		}
            		else if (!inputZipCode.equals("") || !inputCity.equals("") || !inputState.equals(""))
            		{
            		analyzeQuery += "AND country = '"+inputCountry+"' ";
            		}

            	}
            	
           	if(!inputPurpose.equals(""))
            	{
            		if (inputZipCode.equals("") && inputCity.equals("") && inputState.equals("") && inputCountry.equals(""))
            		{
            			analyzeQuery += "visitType = '"+inputPurpose+"' ";
            		}
            		else if (!inputZipCode.equals("") || !inputCity.equals("") || !inputState.equals("") || !inputCountry.equals(""))
            		{
            			analyzeQuery += " AND visitType = '"+inputPurpose+"' ";
            		}
            	}
            	/**
            	if(!inputHotel.equals(""))
            	{
            		if (inputZipCode.equals("") && inputCity.equals("") && inputState.equals("") && inputCountry.equals("") && inputPurpose.equals(""))
            		{
            			analyzeQuery +="placeOfStay = '"+inputHotel+"' ";
            		}
            		else if (!inputZipCode.equals("") || !inputCity.equals("") || !inputState.equals("") || !inputCountry.equals(""))
            		{
            			analyzeQuery += " AND placeOfStay = '"+inputHotel+"' ";
            		}
            	}*/
            	

            	rs = conn.createStatement().executeQuery(analyzeQuery);
             }
             
             
             
             else if (!startDate.equals("") && !endDate.equals(""))
             {
            	 analyzeQuery ="SELECT city, state,zipCode, country, visitType, VisitDetails, numOfVisitors, placeOfStay, email_ID, timestamp FROM VisitorInformation WHERE timestamp >= '"+startDateValue+"' AND timestamp <= '"+endDateValue+"'" ;
             
            	 if (!inputZipCode.equals(""))
            	 {
            	 analyzeQuery += " AND zipCode =  '"+inputZipCode+"' ";
            	 }
            	 
            	if (!inputCity.equals(""))
            	{
            		
            		analyzeQuery += " AND city = '"+inputCity+"' ";
            	}
            	
            	if (!inputState.equals(""))
            	{

            			analyzeQuery += " AND state = '"+inputState+"' ";
          
            	}
            	
            	if (!inputCountry.equals(""))
            	{

            		analyzeQuery += " AND country = '"+inputCountry+"' ";

            	}
            	 
            	if (!inputPurpose.equals(""))
            	{

            		analyzeQuery += " AND visitType = '"+inputPurpose+"' ";

            	}
            	/*if (!inputHotel.equals(""))
            	{

            		analyzeQuery += " AND placeOfStay = '"+inputHotel+"' ";

            	}*/
            	 
            	 
            	 rs = conn.createStatement().executeQuery(analyzeQuery);
   
             }
             int serialNumber=1;
             while (rs.next()) {
                 //get string from db,whichever way 
                 data.add(new Visitors(serialNumber, rs.getString(1),rs.getString(2),  rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10) /**,inputZipCode, 0*/));
    	
    		
                 serialNumberColumn.setCellValueFactory(new PropertyValueFactory<>("serialNumber"));
                 cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
                 stateColumn.setCellValueFactory(new PropertyValueFactory<>("stateName"));
                 zipColumn.setCellValueFactory(new PropertyValueFactory<>("zipCode"));
                 countryColumn.setCellValueFactory(new PropertyValueFactory<>("country"));
                 purposeColumn.setCellValueFactory(new PropertyValueFactory<>("visitType"));
                 detailsColumn.setCellValueFactory(new PropertyValueFactory<>("VisitDetails"));
                 numVisitorColumn.setCellValueFactory(new PropertyValueFactory<>("numOfVisitors"));
                 hotelStayColumn.setCellValueFactory(new PropertyValueFactory<>("placeOfStay"));
                 emailIDColumn.setCellValueFactory(new PropertyValueFactory<>("email_ID"));
                 dateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));
               
                 
                
                 
                 myTable.setItems(null);
                 myTable.setItems(data);
                 serialNumber++;

    		
             }	
             if (check==0){
         		exportAsCSV(analyzeQuery);
         	}
    		
			
		} 
		 catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	

      
    }
    
    private void exportEmail() {
		String filename = currentDate+" Email List.csv";
        try {
        	
        	LocalDate startDateValue = startDate.getValue();
        	LocalDate endDateValue = endDate.getValue();
        	
        	
            FileWriter fw = new FileWriter(filename);
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logininformation", "root", "root");
            String query = "select distinct email_ID from VisitorInformation WHERE timestamp >= '"+startDateValue+"' AND timestamp <= '"+endDateValue+"'" ;
            Statement stmt = conn.createStatement();
            ResultSet rs = (ResultSet)stmt.executeQuery(query);
            while (rs.next()) {
             
             fw.append(rs.getString(1));
             fw.append('\n');
               }
            fw.flush();
            fw.close();
            conn.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
	
		      
	}

    	
    
    }

	
		
	
	


