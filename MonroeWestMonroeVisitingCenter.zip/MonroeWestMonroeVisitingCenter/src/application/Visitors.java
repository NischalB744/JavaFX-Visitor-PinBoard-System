package application;

public class Visitors {
	private int serialNumber;
	private String city;
	private String stateName;
	private String country;
	private String purposeOfVisit;
	private String visitDetails;
	private String numOfVisitors;
	private String placeOfStay;
	private String zipCode;
	private String timeStamp;
	
	private String email_ID;
	
	
	public Visitors(int serialNumber, String city, String stateName, String zipCode, String country, String visitPurpose, String visitDetails, 
			String numOfVisitors,String placeOfStay,String email_ID, String timeStamp/**, String inputzipCode, int numberOfVisitor*/) {
		//zipCode, city, state, country, visitType, visitDetails, numOfVisitors, placeOfStay, email_ID, timeStamp 
		super();
		this.serialNumber = serialNumber;
		this.city = city;
		this.stateName = stateName;
		this.country=country;
		this.purposeOfVisit=visitPurpose;
		this.visitDetails=visitDetails;
		this.placeOfStay=placeOfStay;
		this.zipCode=zipCode;
		this.numOfVisitors=numOfVisitors;
		this.email_ID = email_ID;
		this.timeStamp=timeStamp;
		
	}


	public int getSerialNumber() {
		return serialNumber;
	}


	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getStateName() {
		return stateName;
	}


	public void setStateName(String stateName) {
		this.stateName = stateName;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getPurposeOfVisit() {
		return purposeOfVisit;
	}


	public void setPurposeOfVisit(String purposeOfVisit) {
		this.purposeOfVisit = purposeOfVisit;
	}


	public String getVisitDetails() {
		return visitDetails;
	}


	public void setVisitDetails(String visitDetails) {
		this.visitDetails = visitDetails;
	}


	public String getNumOfVisitors() {
		return numOfVisitors;
	}


	public void setNumOfVisitors(String numOfVisitors) {
		this.numOfVisitors = numOfVisitors;
	}


	public String getPlaceOfStay() {
		return placeOfStay;
	}


	public void setPlaceOfStay(String placeOfStay) {
		this.placeOfStay = placeOfStay;
	}


	public String getZipCode() {
		return zipCode;
	}


	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}


	public String getTimeStamp() {
		return timeStamp;
	}


	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}


	public String getEmail_ID() {
		return email_ID;
	}


	public void setEmail_ID(String email_ID) {
		this.email_ID = email_ID;
	}


}
