package application;

import java.awt.event.KeyAdapter;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;
import com.sun.prism.paint.Color;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.SwipeEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class AdminLoginController<myBorderPane> implements Initializable
{
	@FXML
	private MenuItem menuItemByDate;

	@FXML
	private MenuItem menuItemGeneralQueries;

	@FXML
	private MenuItem menuItemEditVisitors;

	@FXML
	private BorderPane myBorderPane;

	@FXML
	private MenuBar myMenuBar;

	@FXML
	private VBox vBoxForDisplay;

	@FXML
	private Button submitAnalysis;

	@FXML
	private Button btnTextClear;

	@FXML
	private TextField txtFieldZip;
	@FXML
	private TextField txtFieldState;
	@FXML
	private TextField txtFieldCity;
	@FXML
	private TextField txtFieldCountry;
	@FXML
	private HBox hotel;
	@FXML
	private HBox purpose;
	@FXML
	private TextField txtFieldHotelstay;
	@FXML
	private Label labelShowAnalysis;

	@FXML
	private TextField labelStartDate;

	@FXML 
	private HBox hBoxForDisplay;

	/////////////////////////
	@FXML
	private BarChart<String, Number> bc;

	@FXML
	private NumberAxis yAxis;

	@FXML
	private CategoryAxis xAxis;

	//////////////////////
	@FXML
	private Button submitButton;

	@FXML
	private DatePicker startDate;

	@FXML
	private DatePicker endDate;

	@FXML
	private DatePicker dateToEnterForVisitorForm;

	@FXML
	private ScrollPane scrollPaneForTable;
	/////////////////////
	DBConnection myDataBase = new DBConnection();

	//To initializing the variables for gettting input
	/****************************/
	@FXML
	private TextField cityNameTField ;

	@FXML
	private TextField stateNameTField;

	@FXML
	TextField zipCodeTFieldForm;

	@FXML
	TextField countryNameTFieldForm;

	@FXML
	ComboBox<String> cBoxForTravelPurpose;

	@FXML
	RadioButton radioBtnHotelYes;

	@FXML
	RadioButton radioBtnHotelNo;

	@FXML
	TextField txtFieldNumInParty;

	@FXML
	TextField emailIDTField;
	/***************************/
	@FXML
	private HBox hBoxForPieLineBarChart; //HBox inside VBox which includes Pie Chart, Bar Chart, and Line Chart 
	/**************************/
	//For Line Chart
	@FXML
	private NumberAxis numYAxisLineChart;

	@FXML
	private LineChart<String,Number> lineChartInHomeMenu;

	@FXML
	private CategoryAxis monthXAxisLineChart;


	/**************************/
	//For Pie Chart
	@FXML
	private PieChart pieChartInHome;
	/********************/
	private int selectedRowNumber;
	/********************/

	String inputZipCode;
	private String inputCity;
	String inputState;
	String inputCountry;
	String inputPurpose;
	String inputHotel;

	private ObservableList<Visitors> data;

	////////////////////////
	//For Table in the buttom of the scene
	@FXML
	private TableView<Visitors> myTable;

	@FXML
	private TableColumn<Visitors, String> hotelStayColumn;

	@FXML
	private TableColumn<Visitors, String> countryColumn;

	@FXML
	private TableColumn<Visitors, String> purposeColumn;

	@FXML
	private TableColumn<Visitors, String> emailIDColumn;

	@FXML
	private TableColumn<Visitors, String> stateColumn;

	@FXML
	private TableColumn<Visitors, String> detailsColumn;

	@FXML
	private TableColumn<Visitors, String> cityColumn;

	@FXML
	private TableColumn<Visitors, String> numOfPeopleColumn;

	@FXML
	private TableColumn<Visitors, String> dateTimeColumn;

	@FXML
	private TableColumn<Visitors, String> serialNumberColumn;

	@FXML
	private TableColumn<Visitors, String> numVisitorColumn;

	@FXML
	private TableColumn<Visitors, String> zipColumn;

	@FXML
	private MenuItem menuItemAddVisitors;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		topStates(); 
		importDataFromDBToHomeTable();
		numberOfPeopleInLastTwelveMOnthsLineChart();
	}

	private void topStates(){
		ArrayList<String> stateName = new ArrayList<String>();
		ArrayList<Number> visitorNum = new ArrayList<Number>();
		int arraylistSize=0;

		try (Connection connection = myDataBase.getConnection())
		{

			String loadQuery = "SELECT state, SUM(numOfVisitors) FROM VisitorInformation GROUP BY state ORDER BY SUM(numOfVisitors) DESC LIMIT 10;";

			Statement stmt = connection.createStatement();

			ResultSet rstate3 ;
			rstate3=(ResultSet) stmt.executeQuery(loadQuery);
			while (rstate3.next()){
				stateName.add(rstate3.getString(1));
				visitorNum.add(rstate3.getInt(2));
			}

			arraylistSize=stateName.size();
		}

		catch (Exception e)
		{
			e.printStackTrace();
		}
		xAxis.setLabel("State");       
		yAxis.setLabel("Number of Visitors");

		XYChart.Series series1 = new XYChart.Series();
		series1.setName("2017");
		for (int j=0;j<arraylistSize;j++){
			if (stateName.get(j).equals(null)){
				break;
			}
			series1.getData().add(new XYChart.Data(stateName.get(j), visitorNum.get(j)));
		}

		bc.getData().addAll(series1);

	}

	private void numberOfPeopleInLastTwelveMOnthsLineChart()
	{          

		try (Connection connection = myDataBase.getConnection())
		{
			String timeStampQuery = "SELECT timestamp FROM VisitorInformation ORDER BY SN DESC LIMIT 1";
			Statement stmt = connection.createStatement();

			ResultSet mostRecentTimeOfVisitorRS = stmt.executeQuery(timeStampQuery);
			int presentMonth = 0;
			int presentYear = 0;

			while (mostRecentTimeOfVisitorRS.next())
			{
				Timestamp myStartTime = mostRecentTimeOfVisitorRS.getTimestamp(1);
				presentMonth = myStartTime.getMonth() + 1;
				presentYear = myStartTime.getYear() +1900;
			}

			int[] totalVisitorsForLastTwelveMonths = new int[12]; 
			String[] lastTwelveMonths = new String[12];
			HashMap<Integer, String> listOfMonths = new HashMap<Integer, String>() { //Declard Hashmap to map the month in numbers to the alphabetical months
				{
					put(1,"Jan"); put(2,"Feb");	put(3,"Mar"); put(4,"Apr");	put(5,"May" ); put(6,"Jun"); 
					put(7,"Jul"); put(8,"Aug");put(9,"Sep"); put(10,"Oct"); put(11,"Nov"); put(12, "Dec");
				}
			};

			XYChart.Series series = new XYChart.Series();

			Timestamp startTimeStampForDBQuery;
			Timestamp endTimeStampForDBQuery;
			for (int i = 11; i >=0; i--)
			{
				String startOfMonth = presentYear + "-" + presentMonth + "-01 00:00:00";
				String endOfMonth = presentYear + "-" + presentMonth + "-31 00:00:00";

				String numberOfVisitorsInEachMonth = "SELECT sum(numOfVisitors) FROM VisitorInformation WHERE timestamp > '"+startOfMonth+"'  AND timestamp < '"+endOfMonth+"'";
				ResultSet numOfVisitorsResultSet = stmt.executeQuery(numberOfVisitorsInEachMonth);
				while (numOfVisitorsResultSet.next())
				{
					int totalVisitorsFromDB = numOfVisitorsResultSet.getInt(1);
					totalVisitorsForLastTwelveMonths[i] = totalVisitorsFromDB;

					if (presentMonth == 1) //Checks if the month is Jan, so the the Dec of last month can be found
					{
						String monthYearForLineChart = "Jan " + presentYear; 
						lastTwelveMonths[i]= monthYearForLineChart;
						presentMonth = 12;
						presentYear--;
					}

					else
					{
						if (i==0)  // Find both the date and the month of the first data in line chart
						{
							lastTwelveMonths[i] = listOfMonths.get(presentMonth) + " " + presentYear;	
						}

						else
						{
							lastTwelveMonths[i] = listOfMonths.get(presentMonth);
							presentMonth--;
						}
					}
				}
			}

			//This loop is adding data to Line Chart from two declared array
			for (int i = 0;i <12;i++)
			{
				series.getData().add(new XYChart.Data(lastTwelveMonths[i],totalVisitorsForLastTwelveMonths[i]));

			}
			lineChartInHomeMenu.getData().add(series);
		}

		catch (Exception e)
		{
			e.printStackTrace();
		}
	}


	private void importDataFromDBToHomeTable()
	{
		try (Connection connection = myDataBase.getConnection())
		{
			Connection conn = myDataBase.connect();
			data = FXCollections.observableArrayList();
			ResultSet rs = null;
			// Execute query and store result in a resultset

			rs = conn.createStatement().executeQuery("SELECT city, state, zipCode, country, purposeOfVisits, VisitDetails, numOfVisitors, placeOfStay, email_ID, timestamp "
					+ "FROM VisitorInformation ORDER BY SN DESC");

			int serialNumber = 1;
			while (rs.next()) 
			{
				//get string from db,whichever way 
				data.add(new Visitors(serialNumber, rs.getString(1),rs.getString(2),  rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),
						rs.getString(8),rs.getString(9),rs.getString(10)));


				serialNumberColumn.setCellValueFactory(new PropertyValueFactory<>("serialNumber"));
				cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
				stateColumn.setCellValueFactory(new PropertyValueFactory<>("stateName"));
				zipColumn.setCellValueFactory(new PropertyValueFactory<>("zipCode"));
				countryColumn.setCellValueFactory(new PropertyValueFactory<>("country"));
				purposeColumn.setCellValueFactory(new PropertyValueFactory<>("purposeOfVisit"));
				detailsColumn.setCellValueFactory(new PropertyValueFactory<>("VisitDetails"));
				numVisitorColumn.setCellValueFactory(new PropertyValueFactory<>("numOfVisitors"));
				hotelStayColumn.setCellValueFactory(new PropertyValueFactory<>("placeOfStay"));
				emailIDColumn.setCellValueFactory(new PropertyValueFactory<>("email_ID"));
				dateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("timeStamp"));

				myTable.setItems(null);
				myTable.setItems(data);
				serialNumber++;
			}
		}

		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	//This method is called when a admin wants to enter the visitors' information received from paper form
	@FXML
	public void addVisitorFromPaperForm(ActionEvent event) 
	{
		vBoxForDisplay.getChildren().remove(bc);
		myBorderPane.getChildren().remove(scrollPaneForTable);
		vBoxForDisplay.getChildren().clear();

		HBox typeOfVisitHBox = new HBox();

		HBox hotelStayHBox = new HBox();

		/*******************************************/
		cityNameTField = new TextField();
		cityNameTField.setPromptText("City");
		cityNameTField.setFocusTraversable(false);

		stateNameTField= new TextField();
		stateNameTField.setPromptText("State");
		stateNameTField.setFocusTraversable(false);

		/*******************************************/
		zipCodeTFieldForm = new TextField();
		zipCodeTFieldForm.setPromptText("Zip Code");
		zipCodeTFieldForm.setFocusTraversable(false);


		countryNameTFieldForm= new TextField();
		countryNameTFieldForm.setPromptText("Country");
		countryNameTFieldForm.setFocusTraversable(false);

		/*********************************************/

		HBox visitTypeHBox = new HBox();

		Label labelTypeOfVisit = new Label("Travelling for	");
		cBoxForTravelPurpose = new ComboBox<String>();
		cBoxForTravelPurpose.getItems().addAll("Business","Pleasure", "Convention", "Other");
		cBoxForTravelPurpose.setEditable(true);

		visitTypeHBox.getChildren().addAll(labelTypeOfVisit,cBoxForTravelPurpose);

		final ToggleGroup hotelStayGroup = new ToggleGroup();

		Label labelHotelStay= new Label("Hotel Stay	");

		radioBtnHotelYes = new RadioButton("Yes		");
		radioBtnHotelYes.setToggleGroup(hotelStayGroup);

		radioBtnHotelNo = new RadioButton("No");
		radioBtnHotelNo.setToggleGroup(hotelStayGroup);

		hotelStayHBox.getChildren().addAll(labelHotelStay,radioBtnHotelYes,radioBtnHotelNo);

		txtFieldNumInParty = new TextField();
		txtFieldNumInParty.setPromptText("Number in Party");

		emailIDTField = new TextField();
		emailIDTField.setPromptText("Enter the Email ID");

		HBox dateOfVisitHBox = new HBox();
		Label lblDateOfVisitor = new Label("Date");
		lblDateOfVisitor.setPadding(new Insets(10, 25, 10, 10));
		dateToEnterForVisitorForm = new DatePicker();
		dateToEnterForVisitorForm.setPromptText("MM/dd/yyyy");
		dateOfVisitHBox.getChildren().addAll(lblDateOfVisitor,dateToEnterForVisitorForm);

		HBox clearAndAddVisitorHBox = new HBox(15);
		Button btnAddNewVisitorFromForm = new Button(" Add Visitor ");
		Button btnClearVisitorForm = new Button(" Clear ");
		clearAndAddVisitorHBox.getChildren().addAll(btnClearVisitorForm,btnAddNewVisitorFromForm);

		vBoxForDisplay.getChildren().addAll(cityNameTField,stateNameTField, zipCodeTFieldForm, countryNameTFieldForm,hotelStayHBox,emailIDTField,
				txtFieldNumInParty, dateOfVisitHBox, visitTypeHBox, clearAndAddVisitorHBox);

		vBoxForDisplay.setSpacing(10);


		//////This is the method called when add visitor button is clicked
		btnAddNewVisitorFromForm.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try (Connection myConnection = myDataBase.getConnection())
				{
					Connection conX = myDataBase.connect();
					String cityOfVisitor = cityNameTField.getText();

					System.out.println(cityOfVisitor);
					String stateOfVisitor = stateNameTField.getText();
					System.out.println("No state");////////////

					String zipCodeOfVisitor = null;
					System.out.println("My Zip Code"); //////////

					if (zipCodeTFieldForm.getText().equals(""))
					{
						zipCodeOfVisitor = null;
						System.out.println(zipCodeOfVisitor);
					}
					if (!zipCodeTFieldForm.getText().equals(""))
					{
						zipCodeOfVisitor = zipCodeTFieldForm.getText();
					}
					String countryOfVisitor = countryNameTFieldForm.getText();
					System.out.println(countryOfVisitor);
					String placeOfStayOfVisitors = "Not Available";
					if(radioBtnHotelYes.isSelected()){
						placeOfStayOfVisitors = "Yes";
					}
					else if (radioBtnHotelNo.isSelected()){
						placeOfStayOfVisitors = "No";
					}
					String numberInPartyOfVisitor = txtFieldNumInParty.getText();
					String emailOfVisitors = emailIDTField.getText();
					LocalDate visitDateOfVisitor = dateToEnterForVisitorForm.getValue();
					String travelPurposeOfVisitor = (String) cBoxForTravelPurpose.getValue();
					System.out.println("Sanjay");


					String loadQuery = "INSERT INTO VisitorInformation (zipCode,city,state, country,purposeOfVisits,numOfVisitors,placeOfStay,email_ID,timestamp) "
							+ "VALUES ('"+zipCodeOfVisitor+"','"+cityOfVisitor+"','"+stateOfVisitor+"','"+countryOfVisitor+"','"+travelPurposeOfVisitor+"',"
							+ "'"+numberInPartyOfVisitor+"','"+placeOfStayOfVisitors+"','"+ emailOfVisitors+"','"+visitDateOfVisitor+"')";

					Statement stmt = conX.createStatement();
					System.out.println("Hi");


					stmt.executeUpdate(loadQuery);

				}

				catch (Exception excep)
				{
					excep.printStackTrace();
				}

				vBoxForDisplay.getChildren().add(scrollPaneForTable);
				importDataFromDBToHomeTable();
			}
		});
	}

	//This method will edit the visitor information. First, a row will be selected from table
	//the information will be loaded to the forms including text field and other.
	//Will hit the Update button, and a dialog box will appear to ask admin if they want to change
	//Will update the information of the visitor in the database
	@FXML
	public void editVisitorSelectedInTable(ActionEvent event) 
	{
		vBoxForDisplay.getChildren().remove(bc);
		myBorderPane.getChildren().remove(scrollPaneForTable);
		vBoxForDisplay.getChildren().clear();


		vBoxForDisplay.getChildren().add(scrollPaneForTable);
		importDataFromDBToHomeTable();


		//////////////
		//String selected = myTable.getId();
		//int selected = myTable.getSelectionModel().getSelectedIndex();

		//System.out.println(selected);
		/////////////
	}

	@FXML
	private void mouseClickedUpdateInformation(MouseEvent event) 
	{
		selectedRowNumber = myTable.getSelectionModel().getSelectedIndex() + 1;
		System.out.println(selectedRowNumber);
		System.out.println("yep");
		
		/*
		 * ALTER TABLE LoginInformation.UserInformation DROP SN;
		   ALTER TABLE LoginInformation.UserInformation ADD SN MediumINT NOT NULL AUTO_INCREMENT Primary key First;

		 */
	}


	@FXML
	public void analyzeByGeneralQueries(ActionEvent event) 
	{
		vBoxForDisplay.getChildren().remove(bc);
		//myBorderPane.getChildren().remove(scrollPaneForTable);
		scrollPaneForTable.setVisible(false);

		vBoxForDisplay.setPadding(new Insets(10, 50, 80, 50));
		vBoxForDisplay.setSpacing(15);

		hBoxForDisplay = new HBox();

		StackPane paneCity = new StackPane();

		btnTextClear = new Button("X");
		btnTextClear.setShape(new Circle(0.3));
		btnTextClear.setStyle("-fx-background-color: #00FF80; -fx-margin: 15px; -fx-margin: 15px;");

		btnTextClear.setBackground(null);

		//Create a TextField to ask admin to enter city
		txtFieldZip = new TextField();
		txtFieldZip.setPrefWidth(300);
		txtFieldZip.setPrefHeight(40);
		txtFieldZip.setPromptText("Enter the ZipCode");
		txtFieldZip.setFocusTraversable(false);

		txtFieldCity = new TextField();
		txtFieldCity.setPrefWidth(300);
		txtFieldCity.setPrefHeight(40);
		txtFieldCity.setPromptText("Enter the City");
		txtFieldCity.setFocusTraversable(false);

		txtFieldState = new TextField();
		txtFieldState.setPrefWidth(300);
		txtFieldState.setPrefHeight(40);
		txtFieldState.setPromptText("Enter the State");
		txtFieldState.setFocusTraversable(false);

		txtFieldCountry = new TextField();
		txtFieldCountry.setPrefWidth(300);
		txtFieldCountry.setPrefHeight(40);
		txtFieldCountry.setPromptText("Enter the Country");
		txtFieldCountry.setFocusTraversable(false);

		purpose =new HBox();
		final ToggleGroup group1 = new ToggleGroup();
		Label purposelabel =new Label("Visit Purpose");

		RadioButton rb1 = new RadioButton("Business");
		rb1.setToggleGroup(group1);

		RadioButton rb2 = new RadioButton("Casual");
		rb2.setToggleGroup(group1);

		RadioButton rb3 = new RadioButton("Other");
		rb3.setToggleGroup(group1);

		purpose.getChildren().addAll(purposelabel,rb1,rb2,rb3);


		hotel =new HBox();
		final ToggleGroup group = new ToggleGroup();
		Label hotelStay=new Label("Hotel Stay");

		RadioButton yes = new RadioButton("Yes");
		yes.setToggleGroup(group);

		RadioButton no = new RadioButton("No");
		no.setToggleGroup(group);

		hotel.getChildren().addAll(hotelStay,yes,no);


		paneCity.getChildren().addAll(txtFieldZip,btnTextClear);
		btnTextClear.visibleProperty().bind( txtFieldZip.textProperty().isEmpty().not() );
		paneCity.setAlignment(btnTextClear,Pos.CENTER_RIGHT);
		paneCity.setMargin(btnTextClear, new Insets(5, 5, 5, 5));


		labelStartDate = new TextField("Enter the start date");
		hBoxForDisplay.getChildren().add(paneCity);


		startDate = new DatePicker();
		startDate.setPromptText("Start Date MM/dd/yyyy");

		endDate = new DatePicker();
		endDate.setPromptText("End Date  MM/dd/yyyy");


		submitButton = new Button("Submit");

		vBoxForDisplay.getChildren().addAll(hBoxForDisplay,txtFieldState,txtFieldCity,txtFieldCountry,hotel,purpose, startDate,endDate,submitButton);


		btnTextClear.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				txtFieldZip.setText("");
				txtFieldZip.requestFocus();
			}
		});

		submitButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override public void handle(ActionEvent e) {
				vBoxForDisplay.getChildren().remove(bc);
				scrollPaneForTable.setVisible(true);

				//submitQuery.analyzeDataFromDb();
				inputZipCode = txtFieldZip.getText();
				inputCity=txtFieldCity.getText();
				System.out.println(inputCity);
				try {
					//////////////////////

					LocalDate startDateValue = startDate.getValue();
					System.out.println(startDateValue);

					LocalDate endDateValue = endDate.getValue();
					System.out.println(startDateValue);
					//startDateValue.co
					//////////////////////

					Connection conn = myDataBase.connect();
					data = FXCollections.observableArrayList();
					ResultSet rs = null;
					// Execute query and store result in a resultset
					if (startDateValue==null || endDateValue==null){

						rs = conn.createStatement().executeQuery("SELECT city, state,zipCode, country, visitType, VisitDetails, numOfVisitors, placeOfStay, email_ID,"
								+ " timestamp FROM VisitorInformation WHERE zipCode =  '"+inputZipCode+"' " );

						/**
						 * if (inputZipCode !=null)

						 * */

					}
					else
					{
						/**

						 */
						rs = conn.createStatement().executeQuery("SELECT city, state,zipCode, country, visitType, VisitDetails, numOfVisitors, placeOfStay, email_ID, timestamp "
								+ "FROM VisitorInformation WHERE zipCode =  '"+inputZipCode+"' AND timestamp >= '"+startDateValue+"' AND timestamp <= '"+endDateValue+"'" );
					}
					int serialNumber=1;
					while (rs.next()) {
						//get string from db,whichever way 
						data.add(new Visitors(serialNumber, rs.getString(1),rs.getString(2),  rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),
								rs.getString(8),rs.getString(9),rs.getString(10) /**,inputZipCode, 0*/));


						serialNumberColumn.setCellValueFactory(new PropertyValueFactory<>("serialNumber"));
						cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
						stateColumn.setCellValueFactory(new PropertyValueFactory<>("stateName"));
						zipColumn.setCellValueFactory(new PropertyValueFactory<>("zipCode"));
						countryColumn.setCellValueFactory(new PropertyValueFactory<>("country"));
						purposeColumn.setCellValueFactory(new PropertyValueFactory<>("visitType"));
						detailsColumn.setCellValueFactory(new PropertyValueFactory<>("VisitDetails"));
						numVisitorColumn.setCellValueFactory(new PropertyValueFactory<>("numOfVisitors"));
						hotelStayColumn.setCellValueFactory(new PropertyValueFactory<>("placeOfStay"));
						emailIDColumn.setCellValueFactory(new PropertyValueFactory<>("email_ID"));
						dateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));

						myTable.setItems(null);
						myTable.setItems(data);
						serialNumber++;

					}	


				} 
				catch (SQLException e1) {
					e1.printStackTrace();
				}


			}
		});
	}

}
